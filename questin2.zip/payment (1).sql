paymentId,customerId,staffId,item_amount,payment_date,payment_status
12345,36363,222,1280,30/06/2012,Approved
23536,63636,222,290,23/06/2012,Approved

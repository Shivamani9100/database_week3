CREATE TABLE personalinfo (
  Customer_Id int(11) NOT NULL,
  Customer_Name int(11) NOT NULL,
  Customer_Mobile_number int (255) NOT NULL
) 
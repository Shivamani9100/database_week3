CREATE TABLE SALES 
             (SALES_DATE DATE, 
              SALES_PERSON VARCHAR(15), 
              REGION VARCHAR(15), 
              SALES INTEGER);